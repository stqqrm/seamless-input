#pragma once
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "identity.hpp"

inline constexpr unsigned short kTcpPort       = 45454;
inline constexpr unsigned short kDiscoveryPort = 45455;

// What a discovery beacon told us about another seamless-input instance.
struct BeaconInfo {
    std::string ip, host;
    std::string key;                // its PUBLIC KEY (not yet proven: the TCP handshake does that)
    std::uint32_t instance = 0;
    bool server = false;
    bool sameGroup = false;         // it knows our group password
};

// Keys for this peer's UDP audio, derived from the same identity-key secret as the TCP encryption
// but with their own label (so they never equal the TCP keys). Fresh for every TCP connection.
struct PeerAudioKeys {
    std::uint8_t tx[32] = {};     // encrypts audio we send to the peer
    std::uint8_t rx[32] = {};     // decrypts audio the peer sends to us
};

// All callbacks are invoked on a non-GUI thread.
struct NetCallbacks {
    std::function<void(const std::string& msg)> onStatus;
    // 'instance' is the peer's per-run id (also used to identify its audio stream).
    // 'key' is the peer's PUBLIC KEY (64 hex chars); the handshake has already proven
    // that the peer owns the matching private key, so it is safe to use as identity.
    // The peer is accepted only when it knows our group password.
    std::function<void(int id, std::uint32_t instance, const std::string& key,
                       const std::string& name, const std::string& addr, bool incoming,
                       const PeerAudioKeys& audioKeys)> onPeerReady;
    std::function<void(int id)> onPeerLost;
    std::function<void(int id, const std::string& line)> onMessage;
    // UDP discovery beacon from another instance on the LAN.
    std::function<void(const BeaconInfo&)> onBeacon;
    // Subnet scan results.
    std::function<void(const std::string& ip, bool serverRunning)> onScanHost;
    std::function<void(const std::string& ip, const std::string& name)> onHostName;
    std::function<void()> onScanDone;
};

class Network {
public:
    Network(std::string hostName, Identity identity, NetCallbacks cb);
    ~Network();
    Network(const Network&) = delete;
    Network& operator=(const Network&) = delete;

    void Start();
    void Stop();

    std::uint32_t Instance() const;   // this process' unique id

    // Own address: start the server. Otherwise connect; if nobody listens, start our own server.
    void Select(const std::string& ip, bool isLocalAddress);
    void Send(int id, const std::string& line);

    // Group password: instances with the same password connect to each other automatically.
    // Empty = no group.
    void SetGroup(const std::string& password);
    // Scan the subnets of the given (local ip, prefix length) pairs.
    void Scan(const std::vector<std::pair<std::string, int>>& nets);

private:
    struct Impl;
    std::unique_ptr<Impl> d_;
};
